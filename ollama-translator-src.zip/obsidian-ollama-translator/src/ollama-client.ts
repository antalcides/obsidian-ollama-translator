import { requestUrl, RequestUrlParam, RequestUrlResponse } from "obsidian";
import { OllamaTranslatorSettings } from "./settings";

export interface OllamaChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface OllamaChatOptions {
  temperature?: number;
  num_predict?: number;
  top_p?: number;
  repeat_penalty?: number;
}

export interface OllamaChatRequest {
  model: string;
  messages: OllamaChatMessage[];
  stream?: boolean;
  options?: OllamaChatOptions;
}

export interface OllamaChatResponse {
  model: string;
  message: OllamaChatMessage;
  done: boolean;
  prompt_eval_count?: number;
  eval_count?: number;
}

export interface OllamaModel {
  name: string;
  model?: string;
  size: number;
  digest?: string;
  modified_at?: string;
}

function normalizeHost(host: string): string {
  let value = (host || "").trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(value)) value = `http://${value}`;
  return value || "http://localhost:11434";
}

/**
 * Cliente de la API de Ollama.
 *
 * Usa `requestUrl` de Obsidian (no `fetch`) a propósito: `requestUrl` es una
 * petición nativa que NO pasa por el navegador embebido, por lo que evita el
 * bloqueo CORS que Ollama aplica por defecto al origen `app://obsidian.md`.
 */
export class OllamaClient {
  private baseUrl: string;
  private defaultTimeout: number;

  constructor(settings: OllamaTranslatorSettings) {
    this.baseUrl = normalizeHost(settings.ollamaHost);
    this.defaultTimeout = settings.timeout;
  }

  getUrl(): string {
    return this.baseUrl;
  }

  private async request(
    path: string,
    method: string,
    body?: unknown,
    timeoutMs?: number
  ): Promise<RequestUrlResponse> {
    const params: RequestUrlParam = {
      url: `${this.baseUrl}${path}`,
      method,
      headers: { "Content-Type": "application/json" },
      throw: false,
    };
    if (body !== undefined) params.body = JSON.stringify(body);

    // requestUrl no acepta un timeout: se compite contra un temporizador para
    // que una conexión colgada no deje la interfaz esperando indefinidamente.
    const timeout = timeoutMs ?? this.defaultTimeout;
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        requestUrl(params),
        new Promise<never>((_resolve, reject) => {
          timer = setTimeout(
            () =>
              reject(
                new Error(
                  `Tiempo de espera agotado (${timeout} ms) sin respuesta de ${this.baseUrl}. ` +
                    `¿Está Ollama en marcha? (ollama serve)`
                )
              ),
            timeout
          );
        }),
      ]);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  }

  private snippet(response: RequestUrlResponse): string {
    const text = (response.text || "").replace(/\s+/g, " ").trim();
    return text.length > 300 ? `${text.slice(0, 300)}…` : text;
  }

  async listModels(): Promise<OllamaModel[]> {
    const response = await this.request("/api/tags", "GET", undefined, 15000);
    if (response.status >= 400) {
      throw new Error(`Ollama respondió ${response.status} en /api/tags: ${this.snippet(response)}`);
    }
    const data = response.json as { models?: OllamaModel[] } | undefined;
    return Array.isArray(data?.models) ? data.models : [];
  }

  async checkConnection(): Promise<boolean> {
    try {
      const response = await this.request("/api/tags", "GET", undefined, 5000);
      return response.status < 400;
    } catch {
      return false;
    }
  }

  async chat(payload: OllamaChatRequest): Promise<OllamaChatResponse> {
    const response = await this.request("/api/chat", "POST", { ...payload, stream: false });
    if (response.status >= 400) {
      throw new Error(`Ollama /api/chat respondió ${response.status}: ${this.snippet(response)}`);
    }
    const data = response.json as OllamaChatResponse | undefined;
    if (!data || !data.message) {
      throw new Error("Respuesta inesperada de Ollama (sin campo 'message')");
    }
    return data;
  }

  async pullModel(name: string, onProgress?: (percent: number) => void): Promise<void> {
    // requestUrl no permite leer la respuesta en streaming, así que se pide a
    // Ollama una descarga de un solo golpe ("stream": false).
    onProgress?.(0);
    const response = await this.request("/api/pull", "POST", { name, stream: false }, 60 * 60 * 1000);
    if (response.status >= 400) {
      throw new Error(`Ollama /api/pull respondió ${response.status}: ${this.snippet(response)}`);
    }
    onProgress?.(100);
  }

  updateSettings(settings: OllamaTranslatorSettings): void {
    this.baseUrl = normalizeHost(settings.ollamaHost);
    this.defaultTimeout = settings.timeout;
  }
}
