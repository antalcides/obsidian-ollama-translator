import { OllamaClient, OllamaChatMessage, OllamaChatRequest } from "./ollama-client";
import { SUPPORTED_LANGUAGES } from "./settings";

export interface TranslationOptions {
  sourceText: string;
  targetLanguage: string;
  sourceLanguage?: string;
  model: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  chunkSize: number;
  context?: string;
}

export interface TranslationResult {
  translatedText: string;
  model: string;
  targetLanguage: string;
  sourceLanguage: string;
  chunks: number;
  tokensUsed?: number;
  durationMs?: number;
}

export type TranslationProgress = (completedChunks: number, totalChunks: number) => void;

export class TranslationService {
  private client: OllamaClient;

  constructor(client: OllamaClient) {
    this.client = client;
  }

  async translate(options: TranslationOptions, onProgress?: TranslationProgress): Promise<TranslationResult> {
    const startTime = Date.now();
    const chunks = this.buildChunks(options.sourceText, options.chunkSize);
    const targetLangName = SUPPORTED_LANGUAGES[options.targetLanguage] || options.targetLanguage;
    const sourceLangName = options.sourceLanguage
      ? SUPPORTED_LANGUAGES[options.sourceLanguage] || options.sourceLanguage
      : "auto-detectar";

    const translated: string[] = [];
    let tokensUsed = 0;

    for (let index = 0; index < chunks.length; index++) {
      const messages: OllamaChatMessage[] = [
        { role: "system", content: options.systemPrompt },
        {
          role: "user",
          content: this.buildTranslationPrompt(
            chunks[index],
            targetLangName,
            sourceLangName,
            options.context
          ),
        },
      ];

      const request: OllamaChatRequest = {
        model: options.model,
        messages,
        options: {
          temperature: options.temperature,
          num_predict: options.maxTokens,
          top_p: 0.9,
          repeat_penalty: 1.1,
        },
      };

      const response = await this.client.chat(request).catch((error: unknown) => {
        const reason = error instanceof Error ? error.message : String(error);
        throw new Error(
          chunks.length > 1
            ? `Fallo al traducir el bloque ${index + 1} de ${chunks.length}: ${reason}`
            : `Fallo al traducir: ${reason}`
        );
      });

      tokensUsed += (response.prompt_eval_count || 0) + (response.eval_count || 0);
      translated.push(this.cleanOutput(response.message.content || "", chunks[index]));
      onProgress?.(index + 1, chunks.length);
    }

    return {
      translatedText: translated.join("\n\n").trim(),
      model: options.model,
      targetLanguage: options.targetLanguage,
      sourceLanguage: options.sourceLanguage || "auto",
      chunks: chunks.length,
      tokensUsed,
      durationMs: Date.now() - startTime,
    };
  }

  private buildTranslationPrompt(
    text: string,
    targetLanguage: string,
    sourceLanguage: string,
    context?: string
  ): string {
    let prompt = `Traduce el siguiente texto al ${targetLanguage}`;

    if (sourceLanguage !== "auto-detectar") {
      prompt += ` (el texto original está en ${sourceLanguage})`;
    }
    if (context) {
      prompt += `\n\nContexto adicional: ${context}`;
    }
    prompt += `\n\nEs un fragmento de una nota Markdown: conserva la sintaxis Markdown y no añadas comentarios.`;
    prompt += `\n\nTexto a traducir:\n${text}\n\nTraducción:`;
    return prompt;
  }

  /** Divide el texto respetando los bloques de código cercados. */
  private buildChunks(text: string, maxChars: number): string[] {
    const limit = Math.max(500, maxChars || 3000);
    const lines = text.split("\n");
    const chunks: string[] = [];
    let buffer: string[] = [];
    let length = 0;
    let inFence = false;

    const flush = (): void => {
      const chunk = buffer.join("\n").trim();
      if (chunk) chunks.push(chunk);
      buffer = [];
      length = 0;
    };

    for (const line of lines) {
      if (/^\s*(```|~~~)/.test(line)) inFence = !inFence;
      buffer.push(line);
      length += line.length + 1;
      // Nunca se parte dentro de un bloque de código.
      if (!inFence && length >= limit) flush();
    }
    flush();

    if (chunks.length === 0) return [text];

    // Segunda pasada: fragmentos aún demasiado grandes (p. ej. un bloque de
    // código enorme) se dividen por líneas.
    const hardLimit = Math.round(limit * 1.6);
    const result: string[] = [];
    for (const chunk of chunks) {
      if (chunk.length <= hardLimit) {
        result.push(chunk);
        continue;
      }
      let current: string[] = [];
      let size = 0;
      for (const line of chunk.split("\n")) {
        if (size + line.length + 1 > limit && current.length > 0) {
          result.push(current.join("\n"));
          current = [];
          size = 0;
        }
        current.push(line);
        size += line.length + 1;
      }
      if (current.length > 0) result.push(current.join("\n"));
    }
    return result.filter((c) => c.trim().length > 0);
  }

  /** Quita envoltorios y preámbulos que algunos modelos añaden. */
  private cleanOutput(output: string, source: string): string {
    let text = (output || "").trim();

    const fenced = /^```[a-zA-Z0-9]*\n([\s\S]*)\n```$/.exec(text);
    if (fenced && !source.includes("```")) text = fenced[1].trim();

    text = text.replace(/^(?:Traducci[óo]n|Translation|Translated text)\s*:\s*/i, "");
    return text.trim();
  }

  updateSettings(): void {
    // El cliente guarda el host y el timeout; no hay estado adicional aquí.
  }
}
