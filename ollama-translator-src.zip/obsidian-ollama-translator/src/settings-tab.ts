import { App, Notice, PluginSettingTab, Setting } from "obsidian";
import { OllamaTranslatorPlugin } from "./main";
import { DEFAULT_SETTINGS, SUPPORTED_LANGUAGES } from "./settings";
import { OllamaClient, OllamaModel } from "./ollama-client";

export class OllamaTranslatorSettingTab extends PluginSettingTab {
  plugin: OllamaTranslatorPlugin;
  private client: OllamaClient;
  private models: OllamaModel[] = [];
  private isLoadingModels = false;
  private newModelName = "";

  constructor(app: App, plugin: OllamaTranslatorPlugin) {
    super(app, plugin);
    this.plugin = plugin;
    this.client = plugin.getClient();
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Ollama Translator" });

    this.createConnectionSection();
    this.createModelSection();
    this.createTranslationSection();
    this.createAdvancedSection();
    this.createAboutSection();
  }

  private createConnectionSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h3", { text: "Conexión a Ollama" });

    new Setting(containerEl)
      .setName("Host de Ollama")
      .setDesc("URL del servidor Ollama (por defecto: http://localhost:11434)")
      .addText((text) =>
        text
          .setPlaceholder("http://localhost:11434")
          .setValue(this.plugin.settings.ollamaHost)
          .onChange(async (value) => {
            this.plugin.settings.ollamaHost = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Probar conexión")
      .setDesc("Comprueba si Ollama está accesible desde Obsidian")
      .addButton((button) =>
        button
          .setButtonText("Probar")
          .setCta()
          .onClick(async () => {
            const ok = await this.client.checkConnection();
            if (ok) {
              new Notice("✅ Conexión a Ollama correcta");
              await this.loadModels();
              this.display();
            } else {
              new Notice(
                `❌ No se pudo conectar a ${this.client.getUrl()}. Comprueba que Ollama esté en marcha.`,
                10000
              );
            }
          })
      );
  }

  private createModelSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h3", { text: "Modelos" });

    if (this.isLoadingModels) {
      new Setting(containerEl).setName("Cargando modelos…").setDesc("Un momento");
    } else if (this.models.length === 0) {
      new Setting(containerEl)
        .setName("No hay modelos cargados")
        .setDesc("Pulsa «Cargar modelos» o descarga uno nuevo abajo")
        .addButton((button) =>
          button.setButtonText("Cargar modelos").onClick(async () => {
            await this.loadModels();
          })
        );
    } else {
      const names = this.models.map((m) => m.name);
      const current = this.plugin.settings.defaultModel;

      new Setting(containerEl)
        .setName("Modelo por defecto")
        .setDesc("Modelo que se usará para traducir")
        .addDropdown((dropdown) =>
          dropdown
            .addOptions(Object.fromEntries(names.map((n) => [n, n])))
            .setValue(names.includes(current) ? current : names[0] ?? "")
            .onChange(async (value) => {
              this.plugin.settings.defaultModel = value;
              await this.plugin.saveSettings();
            })
        );

      new Setting(containerEl)
        .setName("Modelos instalados")
        .setDesc("Modelos detectados en Ollama")
        .addTextArea((text) =>
          text.setValue(this.models.map((m) => `${m.name} (${this.formatSize(m.size)})`).join("\n")).setDisabled(true)
        );
    }

    new Setting(containerEl)
      .setName("Descargar un modelo")
      .setDesc("Nombre exacto, por ejemplo: llama3.1:8b, qwen2.5:7b, gemma2:9b")
      .addText((text) =>
        text.setPlaceholder("llama3.1:8b").setValue(this.newModelName).onChange((value) => {
          this.newModelName = value;
        })
      )
      .addButton((button) =>
        button.setButtonText("Descargar").onClick(async () => {
          const name = this.newModelName.trim();
          if (!name) {
            new Notice("Escribe un nombre de modelo");
            return;
          }
          button.setDisabled(true).setButtonText("Descargando…");
          try {
            await this.client.pullModel(name);
            new Notice(`✅ Modelo ${name} descargado`);
            this.newModelName = "";
            await this.loadModels();
            this.display();
          } catch (error) {
            new Notice(`❌ ${error instanceof Error ? error.message : String(error)}`, 10000);
          } finally {
            button.setDisabled(false).setButtonText("Descargar");
          }
        })
      );

    new Setting(containerEl).setName("Actualizar lista").addButton((button) =>
      button.setButtonText("Recargar").onClick(async () => {
        await this.loadModels();
      })
    );
  }

  private async loadModels(): Promise<void> {
    this.isLoadingModels = true;
    this.display();
    try {
      this.models = await this.client.listModels();
    } catch (error) {
      new Notice(`Error al cargar modelos: ${error instanceof Error ? error.message : String(error)}`, 10000);
      this.models = [];
    } finally {
      this.isLoadingModels = false;
      this.display();
    }
  }

  private createTranslationSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h3", { text: "Traducción" });

    new Setting(containerEl)
      .setName("Idioma de destino por defecto")
      .setDesc("Idioma al que se traduce con el atajo principal")
      .addDropdown((dropdown) =>
        dropdown
          .addOptions(SUPPORTED_LANGUAGES)
          .setValue(this.plugin.settings.defaultTargetLanguage)
          .onChange(async (value) => {
            this.plugin.settings.defaultTargetLanguage = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Prompt del sistema")
      .setDesc("Instrucciones que recibe el modelo")
      .addTextArea((text) => {
        text
          .setPlaceholder(DEFAULT_SETTINGS.systemPrompt)
          .setValue(this.plugin.settings.systemPrompt)
          .onChange(async (value) => {
            this.plugin.settings.systemPrompt = value;
            await this.plugin.saveSettings();
          });
        text.inputEl.rows = 8;
      });

    new Setting(containerEl)
      .setName("Temperatura")
      .setDesc("0 = determinista, 1 = creativo")
      .addSlider((slider) =>
        slider
          .setLimits(0, 1, 0.1)
          .setValue(this.plugin.settings.temperature)
          .setDynamicTooltip()
          .onChange(async (value) => {
            this.plugin.settings.temperature = value;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Máximo de tokens por bloque")
      .setDesc("Límite de longitud de cada respuesta del modelo")
      .addText((text) =>
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.maxTokens))
          .setValue(String(this.plugin.settings.maxTokens))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (!Number.isNaN(parsed) && parsed > 0) {
              this.plugin.settings.maxTokens = parsed;
              await this.plugin.saveSettings();
            }
          })
      );

    new Setting(containerEl)
      .setName("Tamaño de bloque (caracteres)")
      .setDesc("Las notas largas se traducen por bloques de este tamaño. Menos = más seguro, más = más rápido.")
      .addText((text) =>
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.chunkSize))
          .setValue(String(this.plugin.settings.chunkSize))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (!Number.isNaN(parsed) && parsed >= 500) {
              this.plugin.settings.chunkSize = parsed;
              await this.plugin.saveSettings();
            }
          })
      );

    new Setting(containerEl)
      .setName("Tiempo de espera (ms)")
      .setDesc("Máximo por bloque; con modelos grandes conviene subirlo")
      .addText((text) =>
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.timeout))
          .setValue(String(this.plugin.settings.timeout))
          .onChange(async (value) => {
            const parsed = Number.parseInt(value, 10);
            if (!Number.isNaN(parsed) && parsed > 0) {
              this.plugin.settings.timeout = parsed;
              await this.plugin.saveSettings();
            }
          })
      );
  }

  private createAdvancedSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h3", { text: "Opciones avanzadas" });

    new Setting(containerEl)
      .setName("Reemplazar la selección")
      .setDesc("Sustituye el texto seleccionado por la traducción. Si se desactiva, se muestra en un diálogo.")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.replaceSelection).onChange(async (value) => {
          this.plugin.settings.replaceSelection = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Copia de seguridad antes de reemplazar la nota")
      .setDesc("Crea «nota.backup-FECHA.md» antes de reemplazar una nota completa")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.backupBeforeReplace).onChange(async (value) => {
          this.plugin.settings.backupBeforeReplace = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Copiar al portapapeles")
      .setDesc("Copia también la traducción al portapapeles (con «Reemplazar» desactivado)")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.translateToClipboard).onChange(async (value) => {
          this.plugin.settings.translateToClipboard = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Mostrar notificaciones")
      .setDesc("Avisos al terminar cada traducción")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.showNotifications).onChange(async (value) => {
          this.plugin.settings.showNotifications = value;
          await this.plugin.saveSettings();
        })
      );
  }

  private createAboutSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h3", { text: "Acerca de" });

    new Setting(containerEl)
      .setName("Versión")
      .setDesc("1.0.1")
      .addButton((button) =>
        button
          .setButtonText("Restablecer ajustes")
          .setWarning()
          .onClick(async () => {
            this.plugin.settings = { ...DEFAULT_SETTINGS };
            await this.plugin.saveSettings();
            this.display();
            new Notice("Ajustes restablecidos");
          })
      );

    containerEl.createEl("p", {
      text: "Traducciones privadas y locales mediante Ollama. Autor original: Antalcides Olivo.",
    });
  }

  private formatSize(bytes: number): string {
    if (!bytes) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    const index = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${Number.parseFloat((bytes / 1024 ** index).toFixed(2))} ${units[index]}`;
  }
}
