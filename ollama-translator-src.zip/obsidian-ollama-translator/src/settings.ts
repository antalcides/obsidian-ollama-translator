export interface OllamaTranslatorSettings {
  ollamaHost: string;
  defaultModel: string;
  defaultTargetLanguage: string;
  systemPrompt: string;
  temperature: number;
  maxTokens: number;
  timeout: number;
  chunkSize: number;
  showNotifications: boolean;
  translateToClipboard: boolean;
  replaceSelection: boolean;
  backupBeforeReplace: boolean;
  customModels: string[];
}

export const DEFAULT_SETTINGS: OllamaTranslatorSettings = {
  ollamaHost: "http://localhost:11434",
  defaultModel: "llama3.1:8b",
  defaultTargetLanguage: "es",
  systemPrompt: `Eres un traductor profesional. Traduce el texto proporcionado manteniendo:
- El significado exacto y la intención del autor
- El tono y estilo original (formal, casual, técnico, literario)
- Formato Markdown (encabezados, listas, código, tablas, enlaces)
- Terminología técnica sin traducir si es estándar en el idioma destino
- Nombres propios sin traducir

Devuelve SOLO la traducción, sin explicaciones ni comentarios.`,
  temperature: 0.3,
  maxTokens: 4096,
  timeout: 300000,
  chunkSize: 3000,
  showNotifications: true,
  translateToClipboard: false,
  // El usuario quiere que la traducción REEMPLACE el texto seleccionado.
  replaceSelection: true,
  // Copia de seguridad automática antes de reemplazar una nota completa.
  backupBeforeReplace: true,
  customModels: [],
};

export const SUPPORTED_LANGUAGES: Record<string, string> = {
  auto: "Auto-detectar",
  es: "Español",
  en: "English",
  fr: "Français",
  de: "Deutsch",
  it: "Italiano",
  pt: "Português",
  "pt-BR": "Português (Brasil)",
  ru: "Русский",
  zh: "中文",
  "zh-TW": "繁體中文",
  ja: "日本語",
  ko: "한국어",
  ar: "العربية",
  hi: "हिन्दी",
  nl: "Nederlands",
  pl: "Polski",
  tr: "Türkçe",
  sv: "Svenska",
  da: "Dansk",
  no: "Norsk",
  fi: "Suomi",
  cs: "Čeština",
  hu: "Magyar",
  ro: "Română",
  sk: "Slovenčina",
  hr: "Hrvatski",
  sr: "Српски",
  bg: "Български",
  uk: "Українська",
  he: "עברית",
  th: "ไทย",
  vi: "Tiếng Việt",
  id: "Bahasa Indonesia",
  ms: "Bahasa Melayu",
  tl: "Filipino",
  sw: "Kiswahili",
};
