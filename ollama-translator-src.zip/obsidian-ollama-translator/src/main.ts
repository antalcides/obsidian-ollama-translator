import {
  App,
  ButtonComponent,
  Editor,
  MarkdownView,
  Menu,
  Modal,
  Notice,
  Plugin,
  TFile,
} from "obsidian";
import { DEFAULT_SETTINGS, OllamaTranslatorSettings, SUPPORTED_LANGUAGES } from "./settings";
import { OllamaClient } from "./ollama-client";
import { TranslationResult, TranslationService } from "./translation-service";
import { OllamaTranslatorSettingTab } from "./settings-tab";

type TranslateMode = "replace" | "clipboard" | "modal";
type NoteMode = "new-file" | "replace";

export default class OllamaTranslatorPlugin extends Plugin {
  settings: OllamaTranslatorSettings;
  private client: OllamaClient;
  private translationService: TranslationService;

  async onload(): Promise<void> {
    console.log("[ollama-translator] cargando complemento");

    await this.loadSettings();

    this.client = new OllamaClient(this.settings);
    this.translationService = new TranslationService(this.client);

    this.addSettingTab(new OllamaTranslatorSettingTab(this.app, this));

    const statusBar = this.addStatusBarItem();
    statusBar.setText("🌐 Ollama");
    statusBar.addClass("ollama-translator-status");
    statusBar.setAttribute("aria-label", "Ollama Translator: traducción rápida");
    statusBar.onclick = () => this.openQuickTranslate();

    this.addCommand({
      id: "translate-selection",
      name: "Traducir selección",
      editorCallback: (editor: Editor) => {
        void this.translateSelection(editor, this.settings.defaultTargetLanguage);
      },
      hotkeys: [{ modifiers: ["Mod", "Shift"], key: "t" }],
    });

    this.addCommand({
      id: "translate-selection-to",
      name: "Traducir selección a…",
      editorCallback: (editor: Editor) => {
        this.pickLanguage(async (language) => {
          await this.translateSelection(editor, language);
        });
      },
    });

    this.addCommand({
      id: "translate-note-new-file",
      name: "Traducir nota completa (crear archivo nuevo)",
      callback: () => {
        void this.translateActiveNote("new-file");
      },
    });

    this.addCommand({
      id: "translate-note-replace",
      name: "Traducir nota completa (reemplazar la nota)",
      callback: () => {
        void this.translateActiveNote("replace");
      },
    });

    this.addCommand({
      id: "quick-translate",
      name: "Traducción rápida (modal)",
      callback: () => this.openQuickTranslate(),
      hotkeys: [{ modifiers: ["Mod", "Alt"], key: "t" }],
    });

    this.registerEvent(
      this.app.workspace.on("editor-menu", (menu: Menu, editor: Editor) => {
        if (!editor.getSelection()) return;
        menu.addSeparator();
        menu.addItem((item) =>
          item
            .setTitle("🌐 Traducir selección")
            .setIcon("globe")
            .onClick(() => {
              void this.translateSelection(editor, this.settings.defaultTargetLanguage);
            })
        );
        menu.addItem((item) =>
          item
            .setTitle("🌐 Traducir selección a…")
            .setIcon("languages")
            .onClick(() => {
              this.pickLanguage(async (language) => {
                await this.translateSelection(editor, language);
              });
            })
        );
      })
    );

    this.registerEvent(
      this.app.workspace.on("file-menu", (menu: Menu, file: TFile) => {
        if (file.extension !== "md") return;
        menu.addSeparator();
        menu.addItem((item) =>
          item
            .setTitle("🌐 Traducir nota completa (archivo nuevo)")
            .setIcon("file-text")
            .onClick(() => {
              void this.translateNote(file, "new-file");
            })
        );
        menu.addItem((item) =>
          item
            .setTitle("🌐 Traducir nota completa (reemplazar)")
            .setIcon("languages")
            .onClick(() => {
              void this.translateNote(file, "replace");
            })
        );
      })
    );

    console.log("[ollama-translator] complemento listo");
  }

  onunload(): void {
    console.log("[ollama-translator] complemento descargado");
  }

  async loadSettings(): Promise<void> {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, (await this.loadData()) ?? {});
  }

  async saveSettings(): Promise<void> {
    await this.saveData(this.settings);
    this.client.updateSettings(this.settings);
  }

  getClient(): OllamaClient {
    return this.client;
  }

  getTranslationService(): TranslationService {
    return this.translationService;
  }

  /** Opciones de traducción tomadas de la configuración actual. */
  buildOptions(text: string, targetLanguage: string) {
    return {
      sourceText: text,
      targetLanguage,
      model: this.settings.defaultModel,
      systemPrompt: this.settings.systemPrompt,
      temperature: this.settings.temperature,
      maxTokens: this.settings.maxTokens,
      chunkSize: this.settings.chunkSize,
    };
  }

  pickLanguage(onPicked: (language: string) => void | Promise<void>): void {
    new LanguagePickerModal(this.app, this.settings.defaultTargetLanguage, onPicked).open();
  }

  async translateSelection(editor: Editor, targetLanguage: string): Promise<void> {
    const selection = editor.getSelection();
    if (!selection || !selection.trim()) {
      new Notice("No hay texto seleccionado");
      return;
    }

    const mode: TranslateMode = this.settings.replaceSelection
      ? "replace"
      : this.settings.translateToClipboard
        ? "clipboard"
        : "modal";

    const progress = new ProgressModal(this.app, "Traduciendo selección…");
    progress.open();

    try {
      const result = await this.translationService.translate(
        this.buildOptions(selection, targetLanguage),
        (done, total) => progress.setStatus(`Traduciendo… bloque ${done} de ${total}`)
      );
      progress.close();

      const languageName = SUPPORTED_LANGUAGES[result.targetLanguage] || result.targetLanguage;

      if (mode === "replace") {
        editor.replaceSelection(result.translatedText);
        if (this.settings.showNotifications) new Notice(`Selección traducida a ${languageName}`);
      } else if (mode === "clipboard") {
        await navigator.clipboard.writeText(result.translatedText);
        new Notice("Traducción copiada al portapapeles");
      } else {
        new TranslationResultModal(this.app, selection, result).open();
        if (this.settings.showNotifications) new Notice(`Traducido a ${languageName}`);
      }
    } catch (error) {
      progress.close();
      new Notice(`Error: ${describeError(error)}`, 10000);
    }
  }

  private async translateActiveNote(mode: NoteMode): Promise<void> {
    const view = this.app.workspace.getActiveViewOfType(MarkdownView);
    if (!view?.file) {
      new Notice("No hay una nota Markdown activa");
      return;
    }
    await this.translateNote(view.file, mode);
  }

  async translateNote(file: TFile, mode: NoteMode): Promise<void> {
    const original = await this.app.vault.read(file);
    if (!original.trim()) {
      new Notice("La nota está vacía");
      return;
    }

    this.pickLanguage(async (language) => {
      const progress = new ProgressModal(this.app, `Traduciendo ${file.name}…`);
      progress.open();

      try {
        const result = await this.translationService.translate(
          this.buildOptions(original, language),
          (done, total) => progress.setStatus(`Traduciendo… bloque ${done} de ${total}`)
        );
        progress.close();

        if (mode === "new-file") {
          const name = await this.uniqueName(this.newFileName(file, language));
          const created = await this.app.vault.create(name, result.translatedText);
          new Notice(`Nota traducida creada: ${created.path}`);
          const leaf = this.app.workspace.getLeaf(false);
          await leaf.openFile(created);
        } else {
          if (this.settings.backupBeforeReplace) {
            const backup = await this.uniqueName(this.backupFileName(file));
            await this.app.vault.create(backup, original);
            new Notice(`Copia de seguridad creada: ${backup}`);
          }
          await this.app.vault.modify(file, result.translatedText);
          new Notice(`Nota traducida y reemplazada (${result.chunks} bloque(s))`, 8000);
        }
      } catch (error) {
        progress.close();
        new Notice(`Error: ${describeError(error)}`, 10000);
      }
    });
  }

  openQuickTranslate(): void {
    new QuickTranslateModal(this.app, this).open();
  }

  private newFileName(file: TFile, language: string): string {
    const base = file.path.replace(/\.md$/i, "");
    const suffix = language !== "auto" ? `_${language}` : "";
    return `${base}${suffix}_translated.md`;
  }

  private backupFileName(file: TFile): string {
    const stamp = new Date()
      .toISOString()
      .replace(/[-:]/g, "")
      .replace(/\..+$/, "")
      .replace("T", "-");
    return `${file.path.replace(/\.md$/i, "")}.backup-${stamp}.md`;
  }

  /** Devuelve una ruta libre añadiendo (1), (2)… si ya existe. */
  private async uniqueName(path: string): Promise<string> {
    const exists = (p: string): boolean => this.app.vault.getAbstractFileByPath(p) !== null;
    if (!exists(path)) return path;
    const match = /^(.*?)(\.[^.]*)?$/.exec(path);
    const stem = match?.[1] ?? path;
    const ext = match?.[2] ?? "";
    for (let i = 1; i < 1000; i++) {
      const candidate = `${stem} (${i})${ext}`;
      if (!exists(candidate)) return candidate;
    }
    return `${stem}-${Date.now()}${ext}`;
  }
}

function describeError(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

class LanguagePickerModal extends Modal {
  private targetLanguage: string;
  private onSubmit: (language: string) => void | Promise<void>;

  constructor(app: App, defaultLanguage: string, onSubmit: (language: string) => void | Promise<void>) {
    super(app);
    this.targetLanguage = defaultLanguage;
    this.onSubmit = onSubmit;
  }

  onOpen(): void {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Idioma de destino" });

    const select = contentEl.createEl("select");
    for (const [code, name] of Object.entries(SUPPORTED_LANGUAGES)) {
      const option = select.createEl("option", { value: code, text: name });
      if (code === this.targetLanguage) option.selected = true;
    }
    select.addEventListener("change", () => {
      this.targetLanguage = select.value;
    });

    const actions = contentEl.createDiv({ cls: "modal-button-container" });
    new ButtonComponent(actions)
      .setButtonText("Traducir")
      .setCta()
      .onClick(() => {
        const language = this.targetLanguage;
        this.close();
        void this.onSubmit(language);
      });
    new ButtonComponent(actions).setButtonText("Cancelar").onClick(() => this.close());
  }

  onClose(): void {
    this.contentEl.empty();
  }
}

class TranslationResultModal extends Modal {
  private original: string;
  private result: TranslationResult;

  constructor(app: App, original: string, result: TranslationResult) {
    super(app);
    this.original = original;
    this.result = result;
  }

  onOpen(): void {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("translation-result-modal");

    const languageName =
      SUPPORTED_LANGUAGES[this.result.targetLanguage] || this.result.targetLanguage;
    const header = contentEl.createDiv({ cls: "translation-header" });
    header.createEl("h2", { text: `Traducción → ${languageName}` });

    const actions = header.createDiv({ cls: "translation-actions" });
    new ButtonComponent(actions)
      .setButtonText("Copiar")
      .setIcon("copy")
      .onClick(() => {
        void navigator.clipboard.writeText(this.result.translatedText);
        new Notice("Copiado al portapapeles");
      });
    new ButtonComponent(actions)
      .setButtonText("Reemplazar")
      .setIcon("rotate-cw")
      .onClick(() => {
        const view = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (view?.editor) {
          view.editor.replaceSelection(this.result.translatedText);
          this.close();
        }
      });

    const container = contentEl.createDiv({ cls: "translation-content" });
    const originalSection = container.createDiv({ cls: "translation-section" });
    originalSection.createEl("h3", { text: "Original" });
    originalSection.createEl("pre").createEl("code", { text: this.original });

    const translatedSection = container.createDiv({ cls: "translation-section" });
    translatedSection.createEl("h3", { text: "Traducción" });
    translatedSection.createEl("pre").createEl("code", { text: this.result.translatedText });

    const footer = contentEl.createDiv({ cls: "modal-button-container" });
    new ButtonComponent(footer).setButtonText("Cerrar").onClick(() => this.close());
  }

  onClose(): void {
    this.contentEl.empty();
  }
}

class QuickTranslateModal extends Modal {
  private plugin: OllamaTranslatorPlugin;
  private sourceText = "";
  private translatedText = "";
  private targetLanguage: string;
  private isTranslating = false;

  constructor(app: App, plugin: OllamaTranslatorPlugin) {
    super(app);
    this.plugin = plugin;
    this.targetLanguage = plugin.settings.defaultTargetLanguage;
  }

  onOpen(): void {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("quick-translate-modal");
    contentEl.createEl("h2", { text: "🌐 Traducción rápida" });

    const langSelect = contentEl.createEl("select");
    for (const [code, name] of Object.entries(SUPPORTED_LANGUAGES)) {
      langSelect.createEl("option", { value: code, text: name });
    }
    langSelect.value = this.targetLanguage;
    langSelect.addEventListener("change", () => {
      this.targetLanguage = langSelect.value;
    });

    const sourceArea = contentEl.createEl("textarea", {
      cls: "quick-translate-source",
      attr: { placeholder: "Texto a traducir…", rows: "6" },
    });
    sourceArea.addEventListener("input", () => {
      this.sourceText = sourceArea.value;
    });

    const view = this.app.workspace.getActiveViewOfType(MarkdownView);
    const selection = view?.editor?.getSelection();
    if (selection) {
      sourceArea.value = selection;
      this.sourceText = selection;
    }

    const translateBtn = contentEl.createEl("button", {
      cls: "quick-translate-btn mod-cta",
      text: "Traducir",
    });

    const resultArea = contentEl
      .createDiv({ cls: "quick-translate-result" })
      .createEl("textarea", {
        cls: "quick-translate-target",
        attr: { placeholder: "La traducción aparecerá aquí…", rows: "6", readonly: "true" },
      });

    translateBtn.addEventListener("click", () => {
      void this.doTranslate(translateBtn, resultArea);
    });

    const actions = contentEl.createDiv({ cls: "quick-translate-actions" });
    new ButtonComponent(actions)
      .setButtonText("Copiar")
      .setIcon("copy")
      .onClick(() => {
        if (!this.translatedText) return;
        void navigator.clipboard.writeText(this.translatedText);
        new Notice("Copiado al portapapeles");
      });
    new ButtonComponent(actions)
      .setButtonText("Limpiar")
      .onClick(() => {
        sourceArea.value = "";
        resultArea.value = "";
        this.sourceText = "";
        this.translatedText = "";
      });
    new ButtonComponent(actions).setButtonText("Cerrar").onClick(() => this.close());
  }

  private async doTranslate(button: HTMLButtonElement, resultArea: HTMLTextAreaElement): Promise<void> {
    if (!this.sourceText.trim() || this.isTranslating) return;
    this.isTranslating = true;
    button.disabled = true;
    button.textContent = "Traduciendo…";
    resultArea.value = "";

    try {
      const result = await this.plugin.getTranslationService().translate(
        this.plugin.buildOptions(this.sourceText, this.targetLanguage),
        (done, total) => {
          button.textContent = `Traduciendo… ${done}/${total}`;
        }
      );
      this.translatedText = result.translatedText;
      resultArea.value = this.translatedText;
      if (this.plugin.settings.showNotifications) {
        const languageName = SUPPORTED_LANGUAGES[this.targetLanguage] || this.targetLanguage;
        new Notice(`Traducido a ${languageName}`);
      }
    } catch (error) {
      resultArea.value = `Error: ${describeError(error)}`;
    } finally {
      this.isTranslating = false;
      button.disabled = false;
      button.textContent = "Traducir";
    }
  }

  onClose(): void {
    this.contentEl.empty();
  }
}

class ProgressModal extends Modal {
  private message: string;
  private statusEl: HTMLElement | null = null;

  constructor(app: App, message: string) {
    super(app);
    this.message = message;
  }

  onOpen(): void {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass("progress-modal");
    contentEl.createEl("div", { cls: "progress-spinner" });
    this.statusEl = contentEl.createEl("p", { text: this.message });
  }

  setStatus(text: string): void {
    if (this.statusEl) this.statusEl.setText(text);
  }

  onClose(): void {
    this.contentEl.empty();
  }
}
