import esbuild from "esbuild";
import process from "process";

const production = process.argv.includes("--production");
const watch = process.argv.includes("--watch");

const banner = {
  js: "/*\nEste archivo lo genera esbuild (npm run build).\nNo lo edites a mano: edita src/*.ts\n*/",
};

const options = {
  banner,
  entryPoints: ["src/main.ts"],
  outfile: "main.js",      // <- OJO: en la RAÍZ del complemento, no en dist/
  bundle: true,
  external: ["obsidian", "electron", "@codemirror/*", "@lezer/*"],
  format: "cjs",
  target: "es2018",
  platform: "browser",
  logLevel: "info",
  treeShaking: true,
  sourcemap: production ? false : "inline",
  minify: production,
};

if (watch) {
  const ctx = await esbuild.context(options);
  await ctx.watch();
  console.log("esbuild en modo vigilancia…");
} else {
  await esbuild.build(options);
  console.log(`Compilación ${production ? "de producción" : "de desarrollo"} completada`);
}
